/**
 * app.js
 * ------
 * Talks to the FastAPI backend at /api/*. No agent logic lives here anymore --
 * this is a thin client that renders whatever structured response the
 * backend's RAG + Tools agent returns.
 */

const API_BASE = ""; // same-origin; set to e.g. "http://localhost:8000" if served separately

let sessionId = localStorage.getItem("helpdesk_session_id") || null;

const log = document.getElementById("log");
const input = document.getElementById("input");
const sendBtn = document.getElementById("send");
const statusRow = document.getElementById("statusRow");
const quickChips = document.getElementById("quickChips");

/* ---------------- Status strip ---------------- */
async function loadStatus(){
  try{
    const res = await fetch(`${API_BASE}/api/status`);
    if(!res.ok) throw new Error("status fetch failed");
    const data = await res.json();
    renderStatusRow(data);
  }catch(e){
    statusRow.innerHTML = `<span class="status-chip">Status unavailable</span>`;
  }
}

function renderStatusRow(data){
  const labels = {vpn:"VPN", wifi:"Wi-Fi", email:"Email", printer:"Print services"};
  statusRow.innerHTML = "";
  Object.keys(labels).forEach(key=>{
    const s = data[key] || {status:"operational"};
    const el = document.createElement("div");
    el.className = "status-chip";
    el.innerHTML = `<span class="led ${s.status}"></span>${labels[key]}`;
    statusRow.appendChild(el);
  });
}

/* ---------------- Quick chips ---------------- */
const chips = [
  "My VPN keeps disconnecting",
  "I'm locked out of my account",
  "The printer won't print",
  "My laptop is really slow"
];
chips.forEach(c=>{
  const b = document.createElement("button");
  b.className = "chip";
  b.textContent = c;
  b.onclick = ()=>{ input.value = c; sendMessage(); };
  quickChips.appendChild(b);
});

/* ---------------- Chat rendering ---------------- */
function scrollToBottom(){ log.scrollTop = log.scrollHeight; }

function addUserBubble(text){
  const row = document.createElement("div");
  row.className = "row user";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.appendChild(bubble);
  log.appendChild(row);
  scrollToBottom();
}

function addTyping(){
  const row = document.createElement("div");
  row.className = "row agent";
  row.id = "typingRow";
  row.innerHTML = `<div class="bubble"><div class="typing"><span></span><span></span><span></span></div></div>`;
  log.appendChild(row);
  scrollToBottom();
}

function removeTyping(){
  const t = document.getElementById("typingRow");
  if(t) t.remove();
}

function addErrorNote(msg){
  const div = document.createElement("div");
  div.className = "error-note";
  div.textContent = msg;
  log.appendChild(div);
  scrollToBottom();
}

function addAgentBubble(result){
  const row = document.createElement("div");
  row.className = "row agent";
  const bubble = document.createElement("div");
  bubble.className = "bubble";

  let inner = "";
  if(result.kb_id){
    inner += `<span class="kb-tag">${escapeHtml(result.kb_id)} · ${escapeHtml(result.kb_title)}</span><br>`;
  }
  if(result.steps && result.steps.length){
    inner += `<ol class="steps">${result.steps.map(s=>`<li>${escapeHtml(s)}</li>`).join("")}</ol>`;
  } else if(result.reply){
    inner += escapeHtml(result.reply).replace(/\n/g,"<br>");
  }
  if(result.outage){
    inner += `<div class="outage-note">⚠ ${escapeHtml(result.outage)}</div>`;
  }
  if(result.ticket){
    inner += `<div class="ticket-card">Ticket <span class="id">${escapeHtml(result.ticket.id)}</span> opened
      ${result.ticket.priority ? "· priority " + escapeHtml(result.ticket.priority) : ""}<br>
      ${escapeHtml(result.ticket.summary || "")}<br>
      <span style="color:var(--muted)">A human IT agent will follow up shortly.</span></div>`;
  }
  if(!result.ticket && (result.kb_id || result.steps)){
    inner += `<div class="action-row">
      <button class="action-btn" data-action="worked">That worked, thanks</button>
      <button class="action-btn" data-action="notworked">Still not working</button>
    </div>`;
  }

  bubble.innerHTML = inner;
  row.appendChild(bubble);
  log.appendChild(row);

  bubble.querySelectorAll(".action-btn").forEach(btn=>{
    btn.onclick = ()=>{
      if(btn.dataset.action === "worked"){
        addUserBubble("That worked, thanks!");
        quickReply("Glad that fixed it! Anything else I can help with?");
      } else {
        addUserBubble("Still not working");
        sendToBackend("still not working");
      }
    };
  });

  scrollToBottom();
}

function quickReply(text){
  const row = document.createElement("div");
  row.className = "row agent";
  row.innerHTML = `<div class="bubble">${escapeHtml(text)}</div>`;
  log.appendChild(row);
  scrollToBottom();
}

function escapeHtml(str){
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

/* ---------------- Backend call ---------------- */
async function sendToBackend(message){
  addTyping();
  try{
    const res = await fetch(`${API_BASE}/api/chat`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message, session_id: sessionId})
    });
    if(!res.ok){
      const err = await res.json().catch(()=>({detail:"Unknown error"}));
      throw new Error(err.detail || `Request failed (${res.status})`);
    }
    const data = await res.json();
    sessionId = data.session_id;
    localStorage.setItem("helpdesk_session_id", sessionId);

    removeTyping();
    addAgentBubble(data);
    loadStatus(); // refresh in case a status-affecting tool ran
  }catch(e){
    removeTyping();
    addErrorNote(`Couldn't reach the helpdesk backend: ${e.message}. Is the server running (uvicorn main:app)?`);
  }
}

function sendMessage(){
  const text = input.value.trim();
  if(!text) return;
  addUserBubble(text);
  input.value = "";
  input.style.height = "auto";
  sendToBackend(text);
}

sendBtn.onclick = sendMessage;
input.addEventListener("keydown", (e)=>{
  if(e.key === "Enter" && !e.shiftKey){
    e.preventDefault();
    sendMessage();
  }
});
input.addEventListener("input", ()=>{
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 120) + "px";
});

/* ---------------- Init ---------------- */
window.addEventListener("load", ()=>{
  quickReply("Hi, I'm the IT Helpdesk assistant. Tell me what's going on — or tap one of the quick options below.");
  loadStatus();
});
