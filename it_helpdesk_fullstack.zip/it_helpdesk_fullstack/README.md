# AI IT Helpdesk Agent — Full Stack

A real client-server implementation of **Agent + RAG + Tools**: a FastAPI
backend running the agent (knowledge-base retrieval + tool-calling), and a
browser frontend that talks to it over HTTP.

```
it_helpdesk_fullstack/
├── backend/
│   ├── main.py            # FastAPI app: /api/chat, /api/status, /api/tickets/{id}
│   ├── agent.py            # Agent orchestration (LLM mode + offline mock mode)
│   ├── retrieval.py        # RAG layer: TF-IDF search over the knowledge base
│   ├── tools.py             # Mocked IT tools + JSON schemas for tool-calling
│   └── data/
│       └── knowledge_base.json
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js               # Thin client — all logic lives server-side
├── requirements.txt
└── README.md
```

## Architecture

**Backend does all the thinking.** The frontend is a dumb client: it POSTs
the user's message to `/api/chat` and renders whatever structured JSON comes
back. This is the difference from the single-file HTML demo — logic isn't
duplicated in JavaScript, and you can swap frontends (web, Slack bot, mobile
app) without touching the agent.

**Two agent modes, chosen automatically per session:**
- **LLM mode** — if `ANTHROPIC_API_KEY` is set, the backend uses real
  Claude tool-calling. The model decides when to call `check_system_status`,
  `create_ticket`, `reset_password`, etc.
- **Mock mode** — automatic fallback with no API key needed. Rule-based, but
  exercises the exact same RAG + Tools pipeline, so the frontend is fully
  testable without credentials.

**Sessions** are tracked in-memory (`SESSIONS` dict in `main.py`) so each
browser tab keeps its own conversation state (e.g. "still not working"
correctly ties back to the last issue discussed). Swap this for Redis or a
database to survive server restarts / scale across multiple instances.

## API

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/chat` | `{message, session_id}` → structured agent reply |
| `GET` | `/api/status` | Live status of monitored services (vpn, wifi, email, printer) |
| `GET` | `/api/tickets/{id}` | Look up a ticket |
| `DELETE` | `/api/session/{id}` | Clear a session's conversation state |
| `GET` | `/api/health` | Healthcheck |

**Example `/api/chat` response:**
```json
{
  "session_id": "b3f1...",
  "reply": "",
  "kb_id": "kb-001",
  "kb_title": "VPN Keeps Disconnecting",
  "steps": ["Confirm you're on a stable network...", "..."],
  "outage": "Known incident on VPN Gateway (US-East)...",
  "ticket": null,
  "mode": "mock"
}
```

## Setup & run

```bash
pip install -r requirements.txt

# Optional — for real LLM-driven tool-calling instead of mock mode:
export ANTHROPIC_API_KEY=your_key_here

cd backend
uvicorn main:app --reload --port 8000
```

Then open **http://localhost:8000** — the backend serves the frontend
static files directly, so no separate frontend server is needed. (If you'd
rather run the frontend separately, e.g. from `npx serve frontend`, set
`API_BASE` at the top of `app.js` to `http://localhost:8000`.)

## Try it

- "my vpn keeps disconnecting" → matches KB article + flags a live simulated outage
- "still not working" → escalates and opens a ticket, shown as a ticket card in chat
- "reset my password" → asks for identity verification before doing anything (guardrail)
- Check `GET /api/status` directly to see the raw service status data

## Making it production-ready

1. **Sessions** — move `SESSIONS` to Redis/Postgres; add auth so a session
   maps to a real logged-in user (needed for `check_account_status` /
   `reset_password` to be meaningful).
2. **Real tools** — replace the mocks in `tools.py` with actual API calls
   (ServiceNow/Jira for tickets, Okta/AD for accounts, an internal status
   page for outages). Function signatures and JSON schemas don't need to
   change.
3. **Retrieval at scale** — swap TF-IDF for real embeddings + a vector DB
   (Chroma/Pinecone) once the knowledge base grows past a few dozen articles.
4. **Streaming** — use FastAPI's `StreamingResponse` or a WebSocket so LLM
   replies stream token-by-token instead of arriving all at once.
5. **Observability** — log every tool call (who, what, when) for audit,
   especially for password resets and escalations.
6. **Rate limiting & auth** — protect `/api/chat` from abuse, and require an
   authenticated session before sensitive tools (password reset, account
   lookup) can be invoked at all.
