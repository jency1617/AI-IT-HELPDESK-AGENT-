"""
main.py
-------
FastAPI backend for the AI IT Helpdesk Agent.

Endpoints:
  POST /api/chat            { session_id, message } -> structured agent reply
  GET  /api/status          live status of monitored services
  GET  /api/tickets/{id}    look up a ticket by ID
  GET  /api/health          basic healthcheck

Run:
  uvicorn main:app --reload --port 8000

The frontend (in ../frontend) is also served as static files at "/" so you
can open http://localhost:8000 directly.
"""

import os
import uuid
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from agent import HelpdeskAgent
from tools import _TICKETS, _KNOWN_OUTAGES

app = FastAPI(title="IT Helpdesk Agent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this in production
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# In-memory session store: session_id -> HelpdeskAgent
# In production, back this with Redis or a DB so sessions survive restarts
# and can be shared across multiple server instances.
# ---------------------------------------------------------------------------
SESSIONS: dict[str, HelpdeskAgent] = {}


def get_or_create_session(session_id: Optional[str]) -> tuple[str, HelpdeskAgent]:
    if session_id and session_id in SESSIONS:
        return session_id, SESSIONS[session_id]
    new_id = session_id or str(uuid.uuid4())
    SESSIONS[new_id] = HelpdeskAgent(use_llm=True)
    return new_id, SESSIONS[new_id]


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None


class ChatResponse(BaseModel):
    session_id: str
    reply: str
    kb_id: Optional[str] = None
    kb_title: Optional[str] = None
    steps: Optional[list[str]] = None
    outage: Optional[str] = None
    ticket: Optional[dict] = None
    mode: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="message must not be empty")

    session_id, agent = get_or_create_session(req.session_id)
    result = agent.chat(req.message)
    return ChatResponse(session_id=session_id, **result)


@app.get("/api/status")
def status():
    """Live status of monitored IT services, for the frontend's status strip."""
    services = ["vpn", "wifi", "email", "printer"]
    from tools import check_system_status
    return {svc: check_system_status(svc) for svc in services}


@app.get("/api/tickets/{ticket_id}")
def get_ticket(ticket_id: str):
    ticket = _TICKETS.get(ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="ticket not found")
    return {"ticket_id": ticket_id, **ticket}


@app.delete("/api/session/{session_id}")
def reset_session(session_id: str):
    """Clear a session's conversation state (e.g. user clicks 'start over')."""
    SESSIONS.pop(session_id, None)
    return {"cleared": True}


# ---------------------------------------------------------------------------
# Serve frontend static files (so you can just open http://localhost:8000)
# ---------------------------------------------------------------------------
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
