"""
tools.py
--------
Tool implementations for the IT Helpdesk Agent.

These are MOCKED for demo/classroom purposes so the project runs with zero
external dependencies or credentials. Each function has a docstring and a
matching JSON schema (see TOOL_SCHEMAS below) so it can be wired directly
into an LLM's tool-calling / function-calling interface (Anthropic, OpenAI,
etc.) with minimal changes.

To make this "real": replace the body of each function with an actual API
call (e.g., ServiceNow REST API for tickets, an internal status-page API for
outages, Okta/AD API for password resets) while keeping the same function
signature and return shape.
"""

import random
import uuid
from datetime import datetime, timedelta
from typing import Optional


# ---------------------------------------------------------------------------
# In-memory "systems" the mock tools read from / write to
# ---------------------------------------------------------------------------

_TICKETS = {}

_KNOWN_OUTAGES = [
    {
        "service": "VPN Gateway (US-East)",
        "status": "degraded",
        "started_at": (datetime.now() - timedelta(hours=2)).isoformat(),
        "eta_resolved": (datetime.now() + timedelta(hours=1)).isoformat(),
    }
]

_ACCOUNT_STATUS = {
    "jdoe": {"locked": True, "failed_attempts": 5, "mfa_enrolled": True},
    "asmith": {"locked": False, "failed_attempts": 0, "mfa_enrolled": True},
}


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

def check_system_status(service: str) -> dict:
    """
    Check live status/diagnostics for a given IT service (e.g. 'vpn', 'wifi',
    'email', 'printer_server'). Returns whether it's operational and any
    known incidents.
    """
    service_lower = service.lower()
    for outage in _KNOWN_OUTAGES:
        if service_lower in outage["service"].lower():
            return {
                "service": service,
                "status": outage["status"],
                "details": f"Known incident since {outage['started_at']}. "
                           f"ETA resolution: {outage['eta_resolved']}.",
            }
    return {
        "service": service,
        "status": "operational",
        "details": "No known incidents reported for this service.",
    }


def check_account_status(username: str) -> dict:
    """
    Look up account lock status, failed login attempts, and MFA enrollment
    for a given username.
    """
    record = _ACCOUNT_STATUS.get(username.lower())
    if not record:
        return {"username": username, "found": False, "message": "No account record found."}
    return {
        "username": username,
        "found": True,
        "locked": record["locked"],
        "failed_attempts": record["failed_attempts"],
        "mfa_enrolled": record["mfa_enrolled"],
    }


def reset_password(username: str, verified_identity: bool = False) -> dict:
    """
    Trigger a password reset for a user account. Requires identity to have
    been verified first (e.g., via security questions or manager confirmation)
    -- this models a real IT policy guardrail: the agent should never reset
    a password without confirming identity.
    """
    if not verified_identity:
        return {
            "success": False,
            "message": "Identity verification required before a password reset can be issued. "
                       "Please confirm the user's identity (e.g. employee ID, manager approval) first.",
        }
    temp_password = f"Temp-{uuid.uuid4().hex[:8]}!"
    return {
        "success": True,
        "username": username,
        "message": f"Password reset issued. Temporary password sent to registered recovery email/phone.",
        "temp_password_hint": temp_password,  # in a real system this would never be returned directly
    }


def create_ticket(summary: str, category: str, priority: str = "medium", description: str = "") -> dict:
    """
    Create a support ticket in the ticketing system for issues that couldn't
    be resolved through self-service troubleshooting.
    priority: one of 'low', 'medium', 'high', 'urgent'
    """
    ticket_id = f"TCK-{random.randint(10000, 99999)}"
    _TICKETS[ticket_id] = {
        "summary": summary,
        "category": category,
        "priority": priority,
        "description": description,
        "status": "open",
        "created_at": datetime.now().isoformat(),
    }
    return {
        "ticket_id": ticket_id,
        "status": "open",
        "message": f"Ticket {ticket_id} created with priority '{priority}'. "
                   f"An IT team member will follow up.",
    }


def get_ticket_status(ticket_id: str) -> dict:
    """Look up the current status of an existing support ticket."""
    ticket = _TICKETS.get(ticket_id)
    if not ticket:
        return {"found": False, "message": f"No ticket found with ID {ticket_id}."}
    return {"found": True, "ticket_id": ticket_id, **ticket}


def escalate_to_human(reason: str, urgency: str = "normal") -> dict:
    """
    Escalate the current conversation to a human IT support agent.
    Used when: the issue is security-sensitive (e.g. MFA re-enrollment after
    lost device), the user has tried standard fixes without success, or the
    issue requires access/permissions the agent cannot grant.
    """
    ticket = create_ticket(
        summary=f"Escalation: {reason}",
        category="escalation",
        priority="high" if urgency == "urgent" else "medium",
        description=reason,
    )
    return {
        "escalated": True,
        "ticket_id": ticket["ticket_id"],
        "message": f"This has been escalated to a human IT agent (ticket {ticket['ticket_id']}). "
                   f"They will reach out shortly.",
    }


# ---------------------------------------------------------------------------
# JSON Schemas for LLM tool-calling (Anthropic-style tool definitions)
# ---------------------------------------------------------------------------

TOOL_SCHEMAS = [
    {
        "name": "check_system_status",
        "description": "Check live status/diagnostics for an IT service (vpn, wifi, email, printer_server, etc.) to see if there's a known outage.",
        "input_schema": {
            "type": "object",
            "properties": {
                "service": {"type": "string", "description": "Name of the service to check, e.g. 'vpn', 'email'."}
            },
            "required": ["service"],
        },
    },
    {
        "name": "check_account_status",
        "description": "Look up account lock status, failed login attempts, and MFA enrollment for a username.",
        "input_schema": {
            "type": "object",
            "properties": {
                "username": {"type": "string", "description": "The user's login/username."}
            },
            "required": ["username"],
        },
    },
    {
        "name": "reset_password",
        "description": "Trigger a password reset for a user account. Requires verified_identity=true.",
        "input_schema": {
            "type": "object",
            "properties": {
                "username": {"type": "string"},
                "verified_identity": {"type": "boolean", "description": "Whether the user's identity has been confirmed."},
            },
            "required": ["username"],
        },
    },
    {
        "name": "create_ticket",
        "description": "Create a support ticket for an issue that could not be resolved via self-service troubleshooting.",
        "input_schema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "category": {"type": "string", "description": "e.g. network, hardware, software, account, access"},
                "priority": {"type": "string", "enum": ["low", "medium", "high", "urgent"]},
                "description": {"type": "string"},
            },
            "required": ["summary", "category"],
        },
    },
    {
        "name": "get_ticket_status",
        "description": "Look up the current status of an existing support ticket by ID.",
        "input_schema": {
            "type": "object",
            "properties": {"ticket_id": {"type": "string"}},
            "required": ["ticket_id"],
        },
    },
    {
        "name": "escalate_to_human",
        "description": "Escalate the conversation to a human IT agent. Use for security-sensitive issues, repeated failed fixes, or anything requiring elevated access.",
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {"type": "string"},
                "urgency": {"type": "string", "enum": ["normal", "urgent"]},
            },
            "required": ["reason"],
        },
    },
]


# Dispatch table used by the agent to actually invoke a tool by name
TOOL_FUNCTIONS = {
    "check_system_status": check_system_status,
    "check_account_status": check_account_status,
    "reset_password": reset_password,
    "create_ticket": create_ticket,
    "get_ticket_status": get_ticket_status,
    "escalate_to_human": escalate_to_human,
}
