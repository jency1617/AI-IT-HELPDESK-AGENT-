"""
retrieval.py
------------
A lightweight RAG (Retrieval-Augmented Generation) layer for the IT Helpdesk Agent.

Uses TF-IDF + cosine similarity over the knowledge base. This avoids requiring
an external embedding API or internet access, which makes the project easy to
run and demo in a classroom setting. Swapping in a real embedding model
(OpenAI, Anthropic, sentence-transformers, etc.) later just means replacing
the `vectorize()` internals -- the rest of the agent code doesn't need to change.
"""

import json
import os
from dataclasses import dataclass
from typing import List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class KBArticle:
    id: str
    title: str
    category: str
    symptoms: List[str]
    content: str

    def searchable_text(self) -> str:
        """Combine title, symptoms, and content into one field for indexing."""
        return f"{self.title}. Symptoms: {', '.join(self.symptoms)}. {self.content}"


class KnowledgeBaseRetriever:
    """Loads a JSON knowledge base and retrieves the most relevant articles for a query."""

    def __init__(self, kb_path: str):
        self.kb_path = kb_path
        self.articles: List[KBArticle] = []
        self._vectorizer = None
        self._matrix = None
        self._load()

    def _load(self):
        if not os.path.exists(self.kb_path):
            raise FileNotFoundError(f"Knowledge base not found at {self.kb_path}")

        with open(self.kb_path, "r") as f:
            raw = json.load(f)

        self.articles = [
            KBArticle(
                id=item["id"],
                title=item["title"],
                category=item["category"],
                symptoms=item["symptoms"],
                content=item["content"],
            )
            for item in raw
        ]

        corpus = [a.searchable_text() for a in self.articles]
        self._vectorizer = TfidfVectorizer(stop_words="english")
        self._matrix = self._vectorizer.fit_transform(corpus)

    def search(self, query: str, top_k: int = 3, min_score: float = 0.05) -> List[dict]:
        """
        Return the top_k most relevant KB articles for a natural-language query.
        Each result includes a relevance score so the agent can decide whether
        the match is good enough to use, or whether it should ask a clarifying
        question / escalate instead.
        """
        query_vec = self._vectorizer.transform([query])
        scores = cosine_similarity(query_vec, self._matrix).flatten()

        ranked_idx = scores.argsort()[::-1][:top_k]
        results = []
        for idx in ranked_idx:
            if scores[idx] < min_score:
                continue
            article = self.articles[idx]
            results.append(
                {
                    "id": article.id,
                    "title": article.title,
                    "category": article.category,
                    "content": article.content,
                    "score": round(float(scores[idx]), 3),
                }
            )
        return results

    def get_by_id(self, article_id: str) -> dict | None:
        for a in self.articles:
            if a.id == article_id:
                return {
                    "id": a.id,
                    "title": a.title,
                    "category": a.category,
                    "content": a.content,
                }
        return None


if __name__ == "__main__":
    # Quick manual test
    kb_path = os.path.join(os.path.dirname(__file__), "data", "knowledge_base.json")
    retriever = KnowledgeBaseRetriever(kb_path)
    test_queries = [
        "my vpn keeps dropping every few minutes",
        "I can't log into my account, forgot my password",
        "the printer says offline",
    ]
    for q in test_queries:
        print(f"\nQuery: {q}")
        for r in retriever.search(q):
            print(f"  [{r['score']}] {r['title']} ({r['id']})")
