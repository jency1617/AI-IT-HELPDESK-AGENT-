"""
agent.py
--------
Agent + RAG + Tools orchestration, adapted for a multi-user backend.

Each chat session gets its own HelpdeskAgent instance (own conversation
history / last-discussed-article state), tracked by session_id in main.py.

Two modes, chosen automatically:
  - LLM mode: if ANTHROPIC_API_KEY is set and the `anthropic` package is
    installed. The model itself decides when to call a tool.
  - MOCK mode: rule-based fallback, no API key required. Useful for local
    dev/demo and for the frontend to be fully testable without credentials.

Both modes return the same structured response shape so the frontend
doesn't need to know which mode produced it:

{
  "reply": str,                # main text to show
  "kb_id": str | None,
  "kb_title": str | None,
  "steps": list[str] | None,   # troubleshooting steps, if a KB article matched
  "outage": str | None,        # live outage note, if relevant
  "ticket": {"id","summary","category","priority"} | None,
  "mode": "llm" | "mock"
}
"""

import os
import re
import json

from retrieval import KnowledgeBaseRetriever
from tools import TOOL_SCHEMAS, TOOL_FUNCTIONS, check_system_status, create_ticket, escalate_to_human

KB_PATH = os.path.join(os.path.dirname(__file__), "data", "knowledge_base.json")

SYSTEM_PROMPT = """You are an AI IT Helpdesk Agent. Your job is to help employees resolve common
technical issues quickly and safely.

You have access to:
1. A knowledge base of troubleshooting articles (retrieved and provided to you as context).
2. Tools to check live system status, look up accounts, reset passwords, create support
   tickets, and escalate to a human agent.

Guidelines:
- Ground your troubleshooting steps in the retrieved knowledge base articles when relevant.
- Ask a clarifying question if the user's issue is ambiguous (e.g. which OS, what error message).
- Use check_system_status before telling a user to keep retrying a fix, in case there's a
  known outage.
- Never reset a password without confirming identity first (verified_identity=true).
- If a fix doesn't resolve the issue after reasonable troubleshooting, or the issue is
  security-sensitive (e.g. lost MFA device, suspected compromise), create a ticket or escalate.
- Be concise, step-by-step, and avoid jargon where possible.
"""

_ESCALATE_RE = re.compile(
    r"human|real person|escalate|still (not|isn't|doesn't) work|didn't work|already tried|not resolved|still broken",
    re.I,
)
_RESET_PW_RE = re.compile(r"reset (my )?password", re.I)


class HelpdeskAgent:
    def __init__(self, use_llm: bool = True):
        self.retriever = KnowledgeBaseRetriever(KB_PATH)
        self.history = []          # LLM-mode conversation history
        self.last_article = None   # mock-mode conversation state
        self.use_llm = use_llm and self._has_llm_access()
        self.client = None
        if self.use_llm:
            import anthropic
            self.client = anthropic.Anthropic()

    @staticmethod
    def _has_llm_access() -> bool:
        if not os.environ.get("ANTHROPIC_API_KEY"):
            return False
        try:
            import anthropic  # noqa: F401
            return True
        except ImportError:
            return False

    def retrieve_context(self, user_message: str) -> list:
        return self.retriever.search(user_message, top_k=3)

    # -----------------------------------------------------------------
    # LLM MODE
    # -----------------------------------------------------------------
    def _run_llm_turn(self, user_message: str) -> dict:
        kb_hits = self.retrieve_context(user_message)
        kb_context = "\n\n".join(f"[{a['id']}] {a['title']}\n{a['content']}" for a in kb_hits) or "No closely matching articles found."

        self.history.append({
            "role": "user",
            "content": f"User issue: {user_message}\n\nRelevant knowledge base articles:\n{kb_context}",
        })

        outage_note, ticket_info = None, None

        while True:
            response = self.client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=1024,
                system=SYSTEM_PROMPT,
                tools=TOOL_SCHEMAS,
                messages=self.history,
            )
            self.history.append({"role": "assistant", "content": response.content})

            if response.stop_reason != "tool_use":
                text = "\n".join(b.text for b in response.content if b.type == "text")
                top = kb_hits[0] if kb_hits else None
                return {
                    "reply": text,
                    "kb_id": top["id"] if top else None,
                    "kb_title": top["title"] if top else None,
                    "steps": None,
                    "outage": outage_note,
                    "ticket": ticket_info,
                    "mode": "llm",
                }

            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    fn = TOOL_FUNCTIONS.get(block.name)
                    result = fn(**block.input) if fn else {"error": f"Unknown tool {block.name}"}

                    if block.name == "check_system_status" and result.get("status") != "operational":
                        outage_note = result.get("details")
                    if block.name in ("create_ticket", "escalate_to_human") and "ticket_id" in result:
                        ticket_info = {"id": result["ticket_id"]}
                    elif block.name == "create_ticket" and "ticket_id" in result:
                        ticket_info = {"id": result["ticket_id"]}

                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": json.dumps(result),
                    })
            self.history.append({"role": "user", "content": tool_results})

    # -----------------------------------------------------------------
    # MOCK MODE
    # -----------------------------------------------------------------
    def _service_key(self, article, lower_msg):
        if "vpn" in lower_msg:
            return "vpn"
        if "wifi" in lower_msg or "wi-fi" in lower_msg:
            return "wifi"
        if article and article["category"] == "network":
            return "wifi"
        return None

    def _run_mock_turn(self, user_message: str) -> dict:
        lower = user_message.lower()

        if _ESCALATE_RE.search(lower):
            category = self.last_article["category"] if self.last_article else "general"
            summary = self.last_article["title"] if self.last_article else "Unresolved issue reported by user"
            result = escalate_to_human(reason=summary, urgency="normal")
            return {
                "reply": "I hear you — let's get a person on this. I've escalated it.",
                "kb_id": None, "kb_title": None, "steps": None, "outage": None,
                "ticket": {"id": result["ticket_id"], "summary": summary, "category": category, "priority": "high"},
                "mode": "mock",
            }

        if _RESET_PW_RE.search(lower):
            return {
                "reply": ("Before I can trigger a reset, I need to confirm it's really you — password resets "
                          "require identity verification (employee ID or manager confirmation). Once that's "
                          "done I can issue a temporary password. Want me to flag this for verification now?"),
                "kb_id": None, "kb_title": None, "steps": None, "outage": None, "ticket": None, "mode": "mock",
            }

        kb_hits = self.retrieve_context(user_message)
        if not kb_hits:
            return {
                "reply": ("I couldn't match that to a known issue yet. Could you share a bit more — what "
                          "device/OS, and any exact error message? If we can't narrow it down, I can open "
                          "a ticket for a human agent."),
                "kb_id": None, "kb_title": None, "steps": None, "outage": None, "ticket": None, "mode": "mock",
            }

        article = kb_hits[0]
        self.last_article = article

        outage_note = None
        svc = self._service_key(article, lower)
        if svc:
            status = check_system_status(svc)
            if status["status"] != "operational":
                outage_note = status["details"]

        steps = [s.strip() for s in re.split(r"\d+\.\s*", article["content"]) if s.strip()]

        return {
            "reply": "",
            "kb_id": article["id"],
            "kb_title": article["title"],
            "steps": steps,
            "outage": outage_note,
            "ticket": None,
            "mode": "mock",
        }

    # -----------------------------------------------------------------
    def chat(self, user_message: str) -> dict:
        if self.use_llm:
            return self._run_llm_turn(user_message)
        return self._run_mock_turn(user_message)
